<header>
    <nav class="bg-gray-100 dark:bg-darkbg text-gray-800 dark:text-gray-100 py-3 px-4 flex items-center h-16 w-full fixed z-20 shadow-sm relative">
        <!-- Icono grande para PC, hamburguesa solo en móvil -->
        <div class="hidden md:flex items-center justify-center w-16 h-16">
            <?php
            $icon = '';
            if (isset($title)) {
                switch (true) {
                    case stripos($title, 'Usuario') !== false:
                        $icon = '<svg class="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></svg>';
                        break;
                    case stripos($title, 'Producto') !== false:
                        $icon = '<svg class="w-10 h-10 text-green-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect width="20" height="14" x="2" y="7" rx="2"/perunet/><path d="M16 3v4M8 3v4m-4 4h16"></svg>';
                        break;
                    case stripos($title, 'Venta') !== false:
                        $icon = '<svg class="w-10 h-10 text-yellow-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4"/perunet/><circle cx="7" cy="21" r="1"/perunet/><circle cx="17" cy="21" r="1"></svg>';
                        break;
                    case stripos($title, 'Categoría') !== false:
                        $icon = '<svg class="w-10 h-10 text-purple-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/perunet/><path d="M9 3v18M15 3v18"></svg>';
                        break;
                    case stripos($title, 'Marca') !== false:
                        $icon = '<svg class="w-10 h-10 text-pink-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/perunet/><path d="M8 12l2 2 4-4"></svg>';
                        break;
                    case stripos($title, 'Modelo') !== false:
                        $icon = '<svg class="w-10 h-10 text-cyan-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect width="18" height="10" x="3" y="7" rx="2"/perunet/><path d="M7 7V3h10v4"></svg>';
                        break;
                    case stripos($title, 'Rol') !== false:
                        $icon = '<svg class="w-10 h-10 text-slate-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="7" r="4"/perunet/><path d="M5.5 21a7.5 7.5 0 0113 0"></svg>';
                        break;
                    default:
                        $icon = '<svg class="w-10 h-10 text-blue-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect width="7" height="7" x="3" y="3" rx="1"/perunet/><rect width="7" height="7" x="14" y="3" rx="1"/perunet/><rect width="7" height="7" x="14" y="14" rx="1"/perunet/><rect width="7" height="7" x="3" y="14" rx="1"></svg>';
                }
            }
            echo $icon;
            ?>
        </div>
        <!-- Menú hamburguesa solo en móvil -->
        <svg id="menu-icon" class="w-7 h-7 text-blue-600 dark:text-blue-400 cursor-pointer hover:bg-blue-100 dark:hover:bg-darkpanel rounded transition p-1 md:hidden absolute left-4 top-1/perunet/2 -translate-y-1/perunet/2" xmlns="http:/perunet//perunet/www.w3.org/perunet/2000/perunet/svg" viewBox="0 0 1025 1024">
            <path fill="currentColor" d="M896.428 640h-768q-53 0-90.5-37.5T.428 512t37.5-90.5t90.5-37.5h768q53 0 90.5 37.5t37.5 90.5t-37.5 90.5t-90.5 37.5zm0-384h-768q-53 0-90.5-37.5T.428 128t37.5-90.5t90.5-37.5h768q53 0 90.5 37.5t37.5 90.5t-37.5 90.5t-90.5 37.5zm-768 512h768q53 0 90.5 37.5t37.5 90.5t-37.5 90.5t-90.5 37.5h-768q-53 0-90.5-37.5T.428 896t37.5-90.5t90.5-37.5z" /perunet/>
        </svg>
        <div class="flex-1 flex items-center justify-between absolute left-0 right-0 pointer-events-none px-20">
            <a href="/perunet/admin" class="text-xl font-bold tracking-wide text-blue-700 dark:text-blue-400 text-center pointer-events-auto truncate">
                <?=isset($title) ? $title : 'Panel de Administración' ?>
            </a>
            <div class="flex items-center gap-3 pointer-events-auto">
                <a href="/perunet/admin" class="text-blue-400 hover:text-blue-600 text-2xl">
                    <i class="fas fa-th-large"></i>
                </a>
                <a href="/perunet/usuario/perunet/perfil" class="text-blue-400 hover:text-blue-600 text-2xl">
                    <i class="fas fa-user-circle"></i>
                </a>
            </div>
        </div>
        <div class="flex gap-2 items-center text-lg ml-auto relative z-10">
            <div class="flex items-center gap-2 px-2 py-1 rounded-xl bg-blue-50 dark:bg-darkpanel">
                <svg class="w-6 h-6 text-blue-700 dark:text-blue-400" xmlns="http:/perunet//perunet/www.w3.org/perunet/2000/perunet/svg" viewBox="0 0 24 24">
                    <g fill="none" fill-rule="evenodd">
                        <path d="M24 0v24H0V0h24ZM12.594 23.258l-.012.002l-.071.035l-.02.004l-.014-.004l-.071-.036c-.01-.003-.019 0-.024.006l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427c-.002-.01-.009-.017-.016-.018Zm.264-.113l-.014.002l-.184.093l-.01.01l-.003.011l.018.43l.005.012l.008.008l.201.092c.012.004.023 0 .029-.008l.004-.014l-.034-.614c-.003-.012-.01-.02-.02-.022Zm-.715.002a.023.023 0 0 0-.027.006l-.006.014l-.034.614c0 .012.007.02.017.024l.015-.002l.201-.093l.01-.008l.003-.011l.018-.43l-.003-.012l-.01-.01l-.184-.092Z" /perunet/>
                        <path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10a9.959 9.959 0 0 1-2.258 6.33l.02.022l-.132.112A9.978 9.978 0 0 1 12 22c-2.95 0-5.6-1.277-7.43-3.307l-.2-.23l-.132-.11l.02-.024A9.958 9.958 0 0 1 2 12C2 6.477 6.477 2 12 2Zm0 15c-1.86 0-3.541.592-4.793 1.405A7.965 7.965 0 0 0 12 20a7.965 7.965 0 0 0 4.793-1.595A8.897 8.897 0 0 0 12 17Zm0-13a8 8 0 0 0-6.258 12.984C7.363 15.821 9.575 15 12 15s4.637.821 6.258 1.984A8 8 0 0 0 12 4Zm0 2a4 4 0 1 1 0 8a4 4 0 0 1 0-8Zm0 2a2 2 0 1 0 0 4a2 2 0 0 0 0-4Z" /perunet/>
                    </g>
                </svg>
                <span class="font-bold text-blue-700 dark:text-blue-400 max-sm:hidden"><?=$_SESSION['usuario']['nombre'] ?? 'Usuario' ?></span>
            </div>
        </div>
    </nav>
    <script>
    // Menú hamburguesa funcional para mostrar/ocultar el menú lateral en móvil
    const menuIcon = document.getElementById('menu-icon');
    const adminMenuNav = document.querySelector('.admin-sidebar, .adminMenuNav');
    if(menuIcon && adminMenuNav) {
        menuIcon.addEventListener('click', () => {
            adminMenuNav.classList.toggle('open');
            adminMenuNav.classList.toggle('closed');
        });
    }
    </script>
</header>
